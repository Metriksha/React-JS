import React from "react";
import './myStyles.css'

function footer() {
   
   /* 
  let footerStyle = {
    position:"fixed",
    bottom: "0",
    width: "100%",
    backgroundColor:"yellow"
    
};
*/

  return (
    <>
    
    <footer>
      <p>Copyright &copy; Mytodo.com</p>
    </footer>
    
    </>
  );
}

export default footer;
