import React from 'react'

function Notfound() {
  return (
    <div><h1>Page Not Found Component</h1></div>
  )
}

export default Notfound